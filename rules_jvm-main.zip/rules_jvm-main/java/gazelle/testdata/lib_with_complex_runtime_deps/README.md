# Complex runtime_deps

Loading existing runtime_deps attribute only supports string list values.

Other type are ignored and deleted.

Note that this is not the desired behaviour, simply documenting the current behaviour. Improving this would be welcome.
