package com.example.library;

import com.google.common.primitives.Ints;

public class Library {
    public static int compare(int a, int b) {
        return Ints.compare(a, b);
    }
}
