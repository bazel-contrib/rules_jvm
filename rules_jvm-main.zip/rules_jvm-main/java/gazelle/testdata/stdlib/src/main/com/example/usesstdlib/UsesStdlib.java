package com.example.usesstdlib;

import java.util.List;
import org.w3c.dom.Document;

public class UsesStdlib {
  public void consumeDocument(List<Document> d) {
    System.out.println(d);
  }
}
