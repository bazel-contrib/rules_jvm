package com.example.hello;

import com.idonotexist.MyClass;

public class Hello {
    public static void sayHi() {
        System.out.println("Hi!");
    }
}
