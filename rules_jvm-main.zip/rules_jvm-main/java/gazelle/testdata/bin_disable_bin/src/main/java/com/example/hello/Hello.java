package gazelle.testdata.bin_disable_bin.src.main.java.com.example.hello;

public class Hello {
    public static void main(String[] args) {
        System.out.println("Hello, World!");
    }
}
