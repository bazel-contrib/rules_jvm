package example;

public class Class2 {}
