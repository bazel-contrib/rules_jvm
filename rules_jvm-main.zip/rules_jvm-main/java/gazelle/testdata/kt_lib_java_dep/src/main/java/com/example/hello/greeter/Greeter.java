package com.example.hello.greeter;

public class Greeter {
    public String greet() {
        return "Hello, World!";
    }
}