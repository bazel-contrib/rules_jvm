This is a test.

No generated rules because of the top level gazelle:exclude
