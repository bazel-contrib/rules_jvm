This is a test.

No generated rules because of the example1 gazelle:java_extension
