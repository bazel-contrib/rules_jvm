package com.example.hello;

public class Goodbye {
    public void goodbye() {
        System.out.println("Goodbye!");
    }
}