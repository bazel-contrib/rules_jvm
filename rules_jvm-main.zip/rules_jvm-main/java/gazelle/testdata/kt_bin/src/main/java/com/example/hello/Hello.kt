package com.example.hello

import kotlin.io.println

fun main(vararg args: String) {
  println("Hi!")
}
