package com.example.hello

import kotlin.io.println

fun sayHi() {
  println("Hi!")
}
