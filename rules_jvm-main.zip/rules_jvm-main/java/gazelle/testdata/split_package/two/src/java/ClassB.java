package com.example.split;

public class ClassB {}
