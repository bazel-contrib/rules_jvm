package com.example.app;

import com.example.split.ClassA;
import com.example.split.ClassB;

public class Main {
    ClassA a;
    ClassB b;
}
