package com.example.app

import com.example.split.ClassA
import com.example.split.ClassB

class Main {
    val a = ClassA()
    val b = ClassB()
}
