package com.example.shared_deps.shared_dep;

public class SharedDep {
  public static String module() {
    return "SharedDep";
  }
}
