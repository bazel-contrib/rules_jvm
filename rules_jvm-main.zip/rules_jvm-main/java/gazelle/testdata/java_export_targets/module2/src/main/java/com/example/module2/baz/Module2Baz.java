package com.example.module2.baz;

public class Module2Baz {
  public static String module() {
    return "Module2Baz";
  }
}
