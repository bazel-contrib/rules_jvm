package com.example.export_depending_on_different_package.lib;

public class Lib {
  public static String module() {
    return "Lib";
  }
}
