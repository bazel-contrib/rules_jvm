package com.example.module1.foo;

public class Module1Foo {
  public static String module() {
    return "Module1Foo";
  }

  public String nonStaticModule() {
    return "Module1Foo";
  }
}
