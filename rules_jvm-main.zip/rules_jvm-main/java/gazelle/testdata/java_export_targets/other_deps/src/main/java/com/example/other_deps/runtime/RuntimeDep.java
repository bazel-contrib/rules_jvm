package com.example.other_deps.runtime;

public class RuntimeDep {
  public static String module() {
    return "RuntimeDep";
  }
}
