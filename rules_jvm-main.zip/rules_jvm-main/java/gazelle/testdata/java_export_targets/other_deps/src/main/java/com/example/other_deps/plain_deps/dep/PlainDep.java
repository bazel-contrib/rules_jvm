package com.example.other_deps.plain_deps.dep;

public class PlainDep {
  public static String module() {
    return "PlainDep";
  }
}
