package com.example.nested.child_export;

public class ChildExport {
  public static String module() {
    return "ChildExport";
  }
}
