package com.example.hello;

public class HelloTest {
    public static void sayHi() {
        System.out.println("Hi!");
    }
}
