package com.example.child.grandchild;

import org.junit.Test;

public class FooTest {
  @Test
  public void passes() {}
}
