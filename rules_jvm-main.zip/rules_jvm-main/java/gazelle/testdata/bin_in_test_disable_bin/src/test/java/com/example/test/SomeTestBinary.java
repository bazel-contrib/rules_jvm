package gazelle.testdata.bin_in_test_disable_bin.src.test.java.com.example.test;

public class SomeTestBinary {
  public static void main(String[] args) {
    System.out.println("Test passed!");
  }
}
