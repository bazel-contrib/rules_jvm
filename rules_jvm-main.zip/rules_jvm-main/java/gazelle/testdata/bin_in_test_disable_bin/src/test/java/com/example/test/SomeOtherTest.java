package gazelle.testdata.bin_in_test_disable_bin.src.test.java.com.example.test;

import org.junit.Test;

public class SomeOtherTest {
  @Test
  public void testPasses() {}
}
