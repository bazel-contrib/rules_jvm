package com.example.hello.notworld.justhelpersinmodule.withdirectory;

public class Helper {
  public String toUpperCase(String input) {
    return input.toUpperCase();
  }
}
