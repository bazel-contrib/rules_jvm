package com.example.hello.notworld.withhelpers.withdirectory;

public class Helper {
  public String toUpperCase(String input) {
    return input.toUpperCase();
  }
}
