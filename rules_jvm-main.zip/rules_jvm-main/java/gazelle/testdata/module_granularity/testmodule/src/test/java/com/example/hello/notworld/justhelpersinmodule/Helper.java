package com.example.hello.notworld.justhelpersinmodule;

public class Helper {
  public String getExpectation() {
    return "Not World!";
  }
}
