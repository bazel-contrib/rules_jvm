package com.example.hello.notworld.withhelpers;

public class Helper {
  public String getExpectation() {
    return "Not World!";
  }
}
