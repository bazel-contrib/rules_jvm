package com.example;

import org.junit.jupiter.api.Test;

public class Example5Test {
  @Test
  public void passes() {}
}
