package com.example;

import org.junit.Test;

public class Example4Test {
  @Test
  public void passes() {}
}
