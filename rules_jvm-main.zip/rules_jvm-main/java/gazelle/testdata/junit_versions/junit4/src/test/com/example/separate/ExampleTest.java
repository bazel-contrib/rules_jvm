package com.example.separate;

import org.junit.Test;

public class ExampleTest {
  @Test
  public void passes() {}
}
