package com.example.suite;

import org.junit.Test;

public class ExampleTest {
  @Test
  public void passes() {}
}
