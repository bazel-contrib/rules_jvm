package com.example.hello.greeter

class Greeter {
  fun greet(): String {
    return "Hello, World!"
  }
}
