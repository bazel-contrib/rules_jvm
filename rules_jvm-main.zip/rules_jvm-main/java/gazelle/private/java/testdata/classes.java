package com.example.test;

// This is not a valid Java file.
// It serves to collect examples of class definitions to ensure
// the simplistic parser knows to extract them.

class Class0 {}

public class PublicClass1 {
    public abstract class PublicAbstractClass1 {}

    public final class PublicFinalClass1 {}

    public static class PublicStaticClass1 {}
}
