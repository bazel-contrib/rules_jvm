import org.junit.jupiter.api.Test;

public class NoPackage {
    @Test
    public void test() {

    }
}
