package workspace.com.gazelle.java.javaparser.generators;

import workspace.com.gazelle.java.javaparser.generators.DeleteBookRequest;
import workspace.com.gazelle.java.javaparser.generators.HelloProto;
import com.google.common.primitives.Ints;

public class Hello {
}
