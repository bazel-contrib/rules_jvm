package workspace.com.gazelle.kotlin.javaparser.generators

class MainOnCompanion {
  companion object {
    fun main(args: Array<String>) {}
  }
}
