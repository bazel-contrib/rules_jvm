package workspace.com.gazelle.kotlin.javaparser.generators

class MainInClass {
  companion object {
    @JvmStatic fun main(args: Array<String>) {}
  }
}
