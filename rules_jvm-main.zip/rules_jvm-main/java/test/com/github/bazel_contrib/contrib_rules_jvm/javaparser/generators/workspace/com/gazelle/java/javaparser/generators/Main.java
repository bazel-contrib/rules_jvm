package workspace.com.gazelle.java.javaparser.generators;

public class Main {
    public static void main(String[] args) {}
}
