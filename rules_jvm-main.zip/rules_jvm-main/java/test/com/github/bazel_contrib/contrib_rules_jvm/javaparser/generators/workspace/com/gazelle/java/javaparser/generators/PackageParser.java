package workspace.com.gazelle.java.javaparser.generators;

public class PackageParser {

    public com.gazelle.java.ClasspathParser getParser() { return null;}

    public void setParser(com.gazelle.java.OtherClasspathParse start) { }

    public void castParser (com.gazelle.java.ArrayParse[] parsers) { }
}
