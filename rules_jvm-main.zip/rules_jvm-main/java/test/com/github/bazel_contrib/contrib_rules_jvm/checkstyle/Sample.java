package com.github.bazel_contrib.contrib_rules_jvm.checkstyle;

public class Sample {}
