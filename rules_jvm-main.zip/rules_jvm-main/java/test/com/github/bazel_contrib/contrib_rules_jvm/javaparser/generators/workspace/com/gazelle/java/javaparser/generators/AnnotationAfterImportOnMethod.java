package workspace.com.gazelle.java.javaparser.generators;

import org.junit.jupiter.api.Test;

public class AnnotationAfterImportOnMethod {
    @Test
    public void someTest() {}
}
