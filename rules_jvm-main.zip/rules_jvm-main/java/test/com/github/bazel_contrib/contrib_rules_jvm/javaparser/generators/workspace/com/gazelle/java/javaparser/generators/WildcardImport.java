package workspace.com.gazelle.java.javaparser.generators;

import com.google.common.primitives.*;

public class WildcardImport {
}
