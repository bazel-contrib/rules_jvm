package workspace.com.gazelle.kotlin.javaparser.generators

fun main(vararg args: String) {}
