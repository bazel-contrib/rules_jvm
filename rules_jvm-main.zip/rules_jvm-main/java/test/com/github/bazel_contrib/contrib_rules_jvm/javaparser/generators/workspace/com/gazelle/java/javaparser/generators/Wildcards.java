package workspace.com.gazelle.java.javaparser.generators;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.*;

public class Wildcards {}
