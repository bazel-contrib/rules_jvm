package com.github.bazel_contrib.contrib_rules_jvm.junit5;

import org.junit.jupiter.api.RepeatedTest;

class RepeatsTest {

  @RepeatedTest(3)
  public void bootstrap() {
    // do nothing
  }
}
