package workspace.com.gazelle.java.javaparser.generators;

@WhoKnowsWhereIAmFrom
public class AnnotationWithoutImport {

}
