package workspace.com.gazelle.kotlin.javaparser.generators

const val SOME_CONSTANT = 1
