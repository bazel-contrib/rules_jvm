package workspace.com.gazelle.java.javaparser.generators;

import static com.gazelle.java.javaparser.ClasspathParser.MAIN_CLASS;

public class StaticImports {

}